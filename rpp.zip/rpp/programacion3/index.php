<?php
    date_default_timezone_set('America/Argentina/Buenos_Aires');
    require_once "./helpers/archivos.php";
    require_once "./helpers/token.php";
    require_once "./helpers/imagenes.php";
    require_once "./clases/usuarios.php";
    require_once "./clases/vehiculos.php";
    require_once "./clases/servicios.php";
    require_once "./clases/turnos.php";
    require "vendor/autoload.php";

    // FOLDERS
    $usuarios = "./archivos/usuarios.txt";
    $vehiculos = "./archivos/vehiculos.txt";
    $servicios = "./archivos/servicios.txt";
    $turnos = "./archivos/turnos.txt";

    $metodo = $_SERVER['REQUEST_METHOD'];
    $ruta = $_SERVER['PATH_INFO'];
    $caso = (explode('/', $ruta)[1] ?? '');
    $parametro = (explode('/', $ruta)[2] ?? '');

    switch ($metodo) 
    {
        case 'GET':
            if($caso == "patente")
            {
                $token = Token::ValidarToken();

                if ($token != false) {
                    echo Archivos::BuscarConFiltro($vehiculos, $parametro);
                    
                }
                else {
                    echo "Error de token!";
                } 
            }
            elseif ($caso == "stats") {

                $token = Token::ValidarToken();

                if ($token != false && $token->tipo == 'admin') {
                    echo Archivos::Traer($turnos);
                    
                }
                else {
                    echo "Error de token!";
                } 
            }
            else
            {
                echo "Caso invalido";
            }
                break;

        case 'POST':
            if($caso == "registro")
            {
                if (is_null(Archivos::Buscar($usuarios, $_POST['email']))) {
                    $foto = Imagenes::Mover();
                    $usuario = new Usuario($_POST['email'], $_POST['password'], $_POST['tipo'], $foto);
                    Archivos::GuardarJSON($usuarios, $usuario);

                    echo "Guardado!";
                }
                else{
                    echo "Email repetido!";
                }
            }
            elseif ($caso == "login")
            {
                echo Archivos::ValidarCredenciales($usuarios, $_POST['email'], $_POST['password']);
            }
            elseif ($caso == "vehiculo")
            {
                $token = Token::ValidarToken();

                if ($token != false) {
                    if (is_null(Archivos::BuscarVehiculo($vehiculos, $_POST['patente']))) {
                        $vehiculo = new Vehiculo($_POST['marca'], $_POST['modelo'], $_POST['patente'], $_POST['precio']);
                        Archivos::GuardarJSON($vehiculos, $vehiculo);
    
                        echo "Guardado!";
                    }
                    else{
                        echo "Patente repetida!";
                    }
                }
                else {
                    echo "Error de token!";
                }
            }
            elseif ($caso == "servicio")
            {
                $token = Token::ValidarToken();

                if ($token != false) {
                    if (Archivos::ValidarServicio($servicios, $_POST['tipo'], $_POST['id'])) {
                        $servicio = new Servicio($_POST['id'], $_POST['tipo'], $_POST['precio'], $_POST['demora']);
                        Archivos::GuardarJSON($servicios, $servicio);
    
                        echo "Guardado!";
                    }
                    else{
                        echo "Error de parametros!";
                    }
                }
                else {
                    echo "Error de token!";
                }
            }
            elseif ($caso == "turno")
            {
                $token = Token::ValidarToken();

                if ($token != false) {
                    $id = $_POST['id'];
                    $patente = $_POST['patente'];
                    $fecha = $_POST['fecha'];

                    Archivos::ReservarTurno($id, $patente, $fecha, $turnos, $vehiculos, $servicios);
                }
                else {
                    echo "Error de token!";
                }
            }
            else
            {
                echo "Caso invalido";
            }
            break;

        default:
            echo "Error";
            break;
    }

?>