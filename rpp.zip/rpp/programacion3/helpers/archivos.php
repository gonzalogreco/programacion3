<?php

class Archivos {

    static function GuardarJSON($ruta, $obj){
        $array = Archivos::LeerJSON($ruta);
        $archivo = fopen($ruta, "w");
        
        array_push($array, $obj);
        fwrite($archivo, json_encode($array));
    
        fclose($archivo);
    }

    static function LeerJSON($ruta){
        $array = array();

        if(file_exists($ruta) && filesize($ruta) > 0){
            $archivo = fopen($ruta, "r");
            $array = json_decode(fgets($archivo));

            fclose($archivo);
        }

        return $array;
    }

    static function ActualizarAuto($ruta, $nuevo){
        $lista = self::LeerJSON($ruta);
      
        foreach ($lista as $obj) {
            if ($obj->patente == $nuevo->patente) {
                $obj->fecha_egreso = $nuevo->fecha_egreso;
                $obj->importe = $nuevo->importe;
            }
        }
 
        $archivo = fopen($ruta, "w");
        fwrite($archivo, json_encode($array));
        fclose($archivo);
    }

    static function Buscar($ruta, $email){
        $lista = self::LeerJSON($ruta);

        foreach ($lista as $obj) {
            if ($obj->email == $email) {
                return $obj;
            }
        }

        return null;
    }

    static function BuscarVehiculo($ruta, $patente){
        $lista = self::LeerJSON($ruta);

        foreach ($lista as $obj) {
            if ($obj->patente == $patente) {
                return $obj;
            }
        }

        return null;
    }

    static function BuscarServicio($ruta, $id){
        $lista = self::LeerJSON($ruta);

        foreach ($lista as $obj) {
            if ($obj->id == $id) {
                return $obj;
            }
        }

        return null;
    }

    static function BuscarTurno($ruta, $fecha){
        $lista = self::LeerJSON($ruta);

        foreach ($lista as $obj) {
            if ($obj->fecha == $fecha) {
                return $obj;
            }
        }

        return null;
    }

    static function BuscarConFiltro($ruta, $filtro){
        $lista = self::LeerJSON($ruta);
        $coincidencias = "";
        $flag = false;

        foreach ($lista as $obj) {
            if (strtolower($obj->marca) == strtolower($filtro) ||
                strtolower($obj->modelo) == strtolower($filtro) ||
                strtolower($obj->patente) == strtolower($filtro)) {
                    $coincidencias .= 'Marca: ' . $obj->marca . PHP_EOL . 'Modelo: ' . $obj->modelo . PHP_EOL . 'Patente: ' . $obj->patente . PHP_EOL;
                    $flag = true;
            }
        }

        if ($flag) {
            return $coincidencias;
        }
        else {
            return "No existe: " . $filtro;
        }
    }

    static function ValidarCredenciales($ruta, $email, $password){
        $obj = self::Buscar($ruta, $email);

        if (is_null($obj)) {
            return "No registrado!";
        }
        elseif ($obj->email == $email && $obj->password == $password) {
            return Token::CrearToken($obj->email, $obj->tipo);
        }

        return "Password incorrecto!";
    }

    static function ValidarServicio($ruta, $tipo, $id){
        if (is_null(Archivos::BuscarServicio($ruta, $id)) &&
            ($tipo == "10.000km" ||
            $tipo == "20.000km" ||
            $tipo == "50.000km")) {
                return true;
        }

        return false;
    }

    static function ReservarTurno($id, $patente, $fecha, $ruta, $vehiculos, $servicios){
        $vehiculo = Archivos::BuscarVehiculo($vehiculos, $patente);
        $servicio = Archivos::BuscarServicio($servicios, $id);

        if (!is_null($vehiculo) &&
            !is_null($servicio) &&
            is_null(Archivos::BuscarTurno($ruta, $fecha))) {
                $turno = new Turno($id, $fecha, $patente, $vehiculo->marca, $vehiculo->modelo, $servicio->precio, $servicio->tipo);
                Archivos::GuardarJSON($ruta, $turno);

                echo "Guardado!";
        }
        else {
            echo "No se pudo guardar!";
        }
    }

    static function Traer($ruta) {
        $lista = self::LeerJSON($ruta);
        $encontrados = "";
        
        foreach ($lista as $obj) {
            $encontrados .= "ID: " . $obj->id . PHP_EOL . "Fecha: " . $obj->fecha . PHP_EOL . "Patente: " . $obj->patente . PHP_EOL . "Marca: " . $obj->marca . PHP_EOL . "Modelo: " . $obj->modelo . PHP_EOL . "Precio: " . $obj->precio . PHP_EOL . "Tipo: " . $obj->tipo . PHP_EOL;
        }

        return $encontrados;
    }
}

?>