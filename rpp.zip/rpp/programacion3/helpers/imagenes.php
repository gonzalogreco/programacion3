<?php

class Imagenes {

    public static function Mover(){
        $origen = $_FILES["imagen"]["tmp_name"];
        $destino = './imagenes/' . $_FILES["imagen"]["name"];
        move_uploaded_file($origen, $destino);

        return $destino;
    }
}

?>