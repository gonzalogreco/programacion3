<?php
    require "vendor/autoload.php";
    use \Firebase\JWT\JWT;

class Token {

    private static $key = "primerparcial";

    static function ValidarToken(){
        try {
            $token = $_SERVER['HTTP_TOKEN'];
            $decode = JWT::decode($token, self::$key, array('HS256'));
            return $decode;
        } catch (\Throwable $th) {
            return false;
        }
    }

    static function CrearToken($email, $tipo){
        $payload = array(
            "email" => $email,
            "tipo" => $tipo,
        );

        $token = JWT::encode($payload, self::$key);

        return $token;
    }
}

?>