<?php

    class Usuario
    {
        public $email;
        public $password;
        public $tipo;
        public $foto;

        public function __construct($email, $password, $tipo, $foto){
            $this->email = $email;
            $this->password = $password;
            $this->tipo = $tipo;
            $this->foto = $foto;
        }
    }
?>