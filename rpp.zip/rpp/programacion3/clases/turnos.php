<?php

    class Turno
    {
        public $id;
        public $fecha;
        public $patente;
        public $marca;
        public $modelo;
        public $precio;
        public $tipo;


        public function __construct($id, $fecha, $patente, $marca, $modelo, $precio, $tipo){
            $this->id = $id;
            $this->fecha = $fecha;
            $this->patente = $patente;
            $this->marca = $marca;
            $this->modelo = $modelo;
            $this->precio = $precio;
            $this->tipo = $tipo;
        }
    }
?>